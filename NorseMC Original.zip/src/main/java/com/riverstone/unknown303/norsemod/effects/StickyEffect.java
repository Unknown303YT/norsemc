//package com.riverstone.unknown303.norsemod.effects;
//
//import com.riverstone.unknown303.norsemod.NorseMod;
//import net.minecraft.world.effect.MobEffect;
//import net.minecraft.world.effect.MobEffectCategory;
//import net.minecraft.world.entity.Entity;
//import net.minecraft.world.entity.LivingEntity;
//import org.jetbrains.annotations.Nullable;
//
//import java.util.Objects;
//
//public class StickyEffect extends MobEffect {
//    Double x;
//    Double y;
//    Double z;
//    boolean frozen = false;
//    boolean pass = false;
//    int oldTickCount = 0;
//    public StickyEffect(MobEffectCategory mobEffectCategory, int color) {
//        super(mobEffectCategory, color);
//    }
//
//    @Override
//    public void applyEffectTick(LivingEntity entity, int amplifier) {
//        if (!entity.level().isClientSide) {
//            if (this.x == null) {
//                this.x = entity.getX();
//            }
//            if (this.y == null) {
//                this.y = entity.getY();
//            }
//            if (this.z == null) {
//                this.z = entity.getZ();
//            }
//            if (this.oldTickCount == 0) {
//                this.oldTickCount = Objects.requireNonNull(entity.getServer()).getTickCount();
//            }
//            if (!this.frozen) {
//                if (Objects.requireNonNull(entity.getServer()).getTickCount() <= this.oldTickCount + 10) {
//                    this.frozen = !this.pass;
//                }
//            }
//
//            if (this.frozen) {
//                if (Objects.requireNonNull(entity.getServer()).getTickCount() <= this.oldTickCount + 10) {
//                    entity.teleportTo(this.x, this.y, this.z);
//                } else {
//                    this.x = entity.getX();
//                    this.y = entity.getY();
//                    this.z = entity.getZ();
//                    this.frozen = false;
//                    this.pass = true;
//                }
//            }
//        }
//        super.applyEffectTick(entity, amplifier);
//    }
//
//    @Override
//    public boolean isDurationEffectTick(int pDuration, int pAmplifier) {
//        return true;
//    }
//}
