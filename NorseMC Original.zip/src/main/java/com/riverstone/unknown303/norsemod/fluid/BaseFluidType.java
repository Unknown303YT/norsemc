package com.riverstone.unknown303.norsemod.fluid;

import com.mojang.blaze3d.shaders.FogShape;
import com.mojang.blaze3d.systems.RenderSystem;
import com.riverstone.unknown303.norsemod.NorseMod;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.data.worldgen.DimensionTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.BuiltinDimensionTypes;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.WaterFluid;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidType;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.function.Consumer;

public class BaseFluidType extends FluidType {
    private final ResourceLocation stillTexture;
    private final ResourceLocation flowingTexture;
    private final ResourceLocation overlayTexture;
    private final int tintColor;
    private final Vector3f fogColor;
    private final Float fogEnd;

    public BaseFluidType(final ResourceLocation stillTexture, final ResourceLocation flowingTexture, final ResourceLocation overlayTexture,
                         final int tintColor, final Vector3f fogColor, float fogEnd, Properties properties) {
        super(properties);
        this.stillTexture = stillTexture;
        this.flowingTexture = flowingTexture;
        this.overlayTexture = overlayTexture;
        this.tintColor = tintColor;
        this.fogColor = fogColor;
        this.fogEnd = fogEnd;
    }

    public ResourceLocation getStillTexture() {
        return stillTexture;
    }

    public ResourceLocation getFlowingTexture() {
        return flowingTexture;
    }

    public int getTintColor() {
        return tintColor;
    }

    public ResourceLocation getOverlayTexture() {
        return overlayTexture;
    }

    public Vector3f getFogColor() {
        return fogColor;
    }
    public float getFogEnd() {
        return fogEnd;
    }

    @Override
    public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
        consumer.accept(new IClientFluidTypeExtensions() {
            @Override
            public ResourceLocation getStillTexture() {
                return stillTexture;
            }

            @Override
            public ResourceLocation getFlowingTexture() {
                return flowingTexture;
            }

            @Override
            public @Nullable ResourceLocation getOverlayTexture() {
                return overlayTexture;
            }

            @Override
            public int getTintColor() {
                return tintColor;
            }

            @Override
            public @NotNull Vector3f modifyFogColor(Camera camera, float partialTick, ClientLevel level,
                                                    int renderDistance, float darkenWorldAmount, Vector3f fluidFogColor) {
                return fogColor;
            }

            @Override
            public void modifyFogRender(Camera camera, FogRenderer.FogMode mode, float renderDistance, float partialTick,
                                        float nearDistance, float farDistance, FogShape shape) {
                RenderSystem.setShaderFogStart(1f);
                RenderSystem.setShaderFogEnd(fogEnd);
            }
        });
    }

//    @Override
//    public boolean isVaporizedOnPlacement(Level level, BlockPos pos, FluidStack stack) {
//        if (level.dimensionTypeId() == BuiltinDimensionTypes.NETHER) {
//            return true;
//        } else return level.dimensionTypeId() == BuiltinDimensionTypes.END;
//    }

    @Override
    public boolean canConvertToSource(FluidStack stack) {
        return false;
    }

    @Override
    public boolean move(FluidState state, LivingEntity entity, Vec3 movementVector, double gravity) {
//        entity.self().setDeltaMovement(entity.self().getDeltaMovement().add(0.0, -0.03999999910593033 * entity.self().getAttributeValue((Attribute) ForgeMod.SWIM_SPEED.get()), 0.0));
//        entity.self().setDeltaMovement(entity.self().getDeltaMovement().add(0.0, 0.03999999910593033 * entity.self().getAttributeValue((Attribute)ForgeMod.SWIM_SPEED.get()), 0.0));
//        entity.self().setDeltaMovement(entity.self().getDeltaMovement().add(entity.self().getDeltaMovement().x, ));
        entity.self().setDeltaMovement(entity.self().getDeltaMovement().x - 0.035, entity.self().getDeltaMovement().y * entity.self().getAttributeValue((Attribute)ForgeMod.SWIM_SPEED.get()), entity.self().getDeltaMovement().z - 0.035);
        if (entity.self().getDeltaMovement().x < 0) {
            if (entity.self().getDeltaMovement().z < 0) {
                double newN = entity.self().getDeltaMovement().x + 0.035;
                entity.self().setDeltaMovement(newN, entity.self().getDeltaMovement().y * entity.self().getAttributeValue((Attribute)ForgeMod.SWIM_SPEED.get()), newN);
            } else {
                double newX = entity.self().getDeltaMovement().x + 0.035;
                if (entity.self().getLookAngle().x == 45)
                entity.self().setDeltaMovement(entity.self().getDeltaMovement().x + 0.035, entity.self().getDeltaMovement().y * entity.self().getAttributeValue((Attribute)ForgeMod.SWIM_SPEED.get()), entity.self().getDeltaMovement().z - 0.035);
            }
        } else {
            if (entity.self().getDeltaMovement().z < 0) {
                entity.self().setDeltaMovement(entity.self().getDeltaMovement().x - 0.035, entity.self().getDeltaMovement().y * entity.self().getAttributeValue((Attribute)ForgeMod.SWIM_SPEED.get()), entity.self().getDeltaMovement().z + 0.035);
            } else {
                entity.self().setDeltaMovement(entity.self().getDeltaMovement().x - 0.035, entity.self().getDeltaMovement().y * entity.self().getAttributeValue((Attribute)ForgeMod.SWIM_SPEED.get()), entity.self().getDeltaMovement().z - 0.035);
            }
        }
        NorseMod.LOGGER.info(String.valueOf(entity.self().getDeltaMovement().x));
        NorseMod.LOGGER.info(String.valueOf(entity.self().getDeltaMovement().z));
        return false;
    }
}
