package com.riverstone.unknown303.norsemod.entities.client.armor;

import com.riverstone.unknown303.norsemod.items.custom.BoneSteelArmorItem;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoArmorRenderer;

public class BoneSteelArmorRenderer extends GeoArmorRenderer<BoneSteelArmorItem> {
    public BoneSteelArmorRenderer() {
        super(new BoneSteelArmorModel());
    }
}
