package com.riverstone.unknown303.norsemod.entities.client.armor;

import com.riverstone.unknown303.norsemod.NorseMod;
import com.riverstone.unknown303.norsemod.items.custom.BoneSteelArmorItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class BoneSteelArmorModel extends GeoModel<BoneSteelArmorItem> {
    @Override
    public ResourceLocation getModelResource(BoneSteelArmorItem animatable) {
        return new ResourceLocation(NorseMod.MOD_ID, "geo/bs_armor.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(BoneSteelArmorItem animatable) {
        return new ResourceLocation(NorseMod.MOD_ID, "textures/models/armor/bs_armor.png");
    }

    @Override
    public ResourceLocation getAnimationResource(BoneSteelArmorItem animatable) {
        return new ResourceLocation(NorseMod.MOD_ID, "animations/bs_armor.animation.json");
    }
}
